package com.microservice.order.exception;

public class RuleValidationException extends RuntimeException{
	
	public RuleValidationException(String message) {
		super(message);
	}

}
